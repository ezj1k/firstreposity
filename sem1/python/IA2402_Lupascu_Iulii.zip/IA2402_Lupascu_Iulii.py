import datetime
import re
import os

FILENAME = "tranzactii.txt"

#Verificari

def valid_date(data_str):
    try:
        if not re.match(r"\d{2}\.\d{2}\.2025", data_str):
            return False
        data = datetime.datetime.strptime(data_str, "%d.%m.%Y").date()
        
        # Afișăm data curentă a sistemului pentru debug
        print("Data curentă a sistemului este:", datetime.date.today())
        
        return datetime.date(2025, 1, 1) <= data <= datetime.date.today()
    except ValueError:
        return False

def valid_time(ora_str):
    try:
        if not re.match(r"\d{2}:\d{2}", ora_str):
            return False
        ora = datetime.datetime.strptime(ora_str, "%H:%M").time()
        return True
    except ValueError:
        return False

def valid_nume(nume):
    if len(nume) < 1 or len(nume) > 20:
        return False
    return all(re.match(r"^[A-Za-z\-]+$", parte) for parte in nume.split("-"))

def valid_suma_tip(suma_str, tip):
    try:
        suma = float(suma_str)
        if suma > 0 and tip == "profit":
            return True
        if suma <= 0 and tip == "pierdere":
            return True
    except ValueError:
        pass
    return False

def valid_tip(tip):
    return tip in ("profit", "pierdere")

#Functii de actiune

def incarca_tranzactii():
    tranzactii = []
    if not os.path.exists(FILENAME):
        return tranzactii
    with open(FILENAME, "r") as f:
        for linie in f:
            data, ora, nume, prenume, suma, tip = linie.strip().split(",")
            tranzactii.append({
                "data": data,
                "ora": ora,
                "nume": nume,
                "prenume": prenume,
                "suma": float(suma),
                "tip": tip
            })
    return tranzactii

def salveaza_tranzactie(tranzactie):
    with open(FILENAME, "a") as f:
        f.write(",".join([
            tranzactie["data"],
            tranzactie["ora"],
            tranzactie["nume"],
            tranzactie["prenume"],
            str(tranzactie["suma"]),
            tranzactie["tip"]
        ]) + "\n")

def calculeaza_sold(tranzactii):
    sold = 0
    for t in tranzactii:
        sold += t["suma"]
    return sold

def tranzactii_pe_manager(tranzactii):
    contor = {}
    for t in tranzactii:
        cheie = f"{t['nume']} {t['prenume']}"
        contor[cheie] = contor.get(cheie, 0) + 1
    return contor

def afiseaza_tranzactie(t):
    print(f"Data: {t['data']}, Ora: {t['ora']}, Manager: {t['nume']} {t['prenume']}, Suma: {t['suma']}, Tip: {t['tip']}")

#Meniul

def meniu():
    while True:
        print("\n1) Introduceți datele tranzacțiilor")
        print("2) Afișați soldul curent")
        print("3) Afișați numărul de tranzacții per manager")
        print("4) Afișați cea mai profitabilă tranzacție")
        print("5) Afișați cea mai neprofitabilă tranzacție")
        print("6) Ieșire")

        opt = input("Alegeți opțiunea: ")

        if opt == "1":
            tranzactie = {}
            while True:
                tranzactie["data"] = input("Data (zz.ll.2025): ")
                if not valid_date(tranzactie["data"]):
                    print("Dată invalidă. Încercați din nou.")
                    continue

                tranzactie["ora"] = input("Ora (hh:mm): ")
                if not valid_time(tranzactie["ora"]):
                    print("Oră invalidă. Încercați din nou.")
                    continue

                tranzactie["nume"] = input("Nume manager: ")
                if not valid_nume(tranzactie["nume"]):
                    print("Nume invalid. Încercați din nou.")
                    continue

                tranzactie["prenume"] = input("Prenume manager: ")
                if not valid_nume(tranzactie["prenume"]):
                    print("Prenume invalid. Încercați din nou.")
                    continue

                suma = input("Suma tranzacției: ")
                tip = input("Tip tranzacție (profit/pierdere): ")
                if not valid_tip(tip) or not valid_suma_tip(suma, tip):
                    print("Suma sau tip invalid. Încercați din nou.")
                    continue

                tranzactie["suma"] = float(suma)
                tranzactie["tip"] = tip
                salveaza_tranzactie(tranzactie)
                print("Tranzacție înregistrată cu succes.")
                break

        elif opt == "2":
            tranzactii = incarca_tranzactii()
            print(f"Sold curent: {calculeaza_sold(tranzactii):.2f}")

        elif opt == "3":
            tranzactii = incarca_tranzactii()
            statistici = tranzactii_pe_manager(tranzactii)
            for manager, count in statistici.items():
                print(f"{manager}: {count} tranzacții")

        elif opt == "4":
            tranzactii = incarca_tranzactii()
            if not tranzactii:
                print("Nu există tranzacții.")
                continue
            cea_mai_mare = max([t for t in tranzactii if t["suma"] > 0], key=lambda t: t["suma"], default=None)
            if cea_mai_mare:
                afiseaza_tranzactie(cea_mai_mare)
            else:
                print("Nu există tranzacții profitabile.")

        elif opt == "5":
            tranzactii = incarca_tranzactii()
            if not tranzactii:
                print("Nu există tranzacții.")
                continue
            cea_mai_mica = min([t for t in tranzactii if t["suma"] <= 0], key=lambda t: t["suma"], default=None)
            if cea_mai_mica:
                afiseaza_tranzactie(cea_mai_mica)
            else:
                print("Nu există tranzacții pierdere.")

        elif opt == "6":
            print("La revedere!")
            break

        else:
            print("Opțiune invalidă. Încercați din nou.")

#Start
if __name__ == "__main__":
    meniu()