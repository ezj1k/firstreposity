const nume=document.getElementById("nume");
const email=document.getElementById("email");
const telefon=document.getElementById("telefon");
const addcontact=document.getElementById("addcontact");
const telefonerror=document.getElementById("telefonerror");
const emailerror=document.getElementById("emailerror");
const numeerror=document.getElementById("numeerror");
const contactnou=document.getElementById("contactnou");
const cautacont = document.getElementById("cautacont");

let data=JSON.parse(localStorage.getItem("content")) || [];

class Contact{
constructor(nume, email, telefon){
    this.nume=nume;
    this.email=email;
    this.telefon=telefon;
};
}

const numeregex=/[A-Z][a-z]{2,20}(\-[A-Z][a-z]{2,20})*/;
const emailregex=/[a-z0-9._%+-]{1,64}@[a-z0-9.-]{2,9}\.[a-z]{2,4}/;
const telefonregex=/0[6-7][0-9]{7,7}/;

function validare_nume(){
    if(!numeregex.test(nume.value)){
        numeerror.innerText="Numele e gresit";
        return false;
    }
    else{
        numeerror.innerText="";
        return true;
    }
}

function validare_email(){
    if(!emailregex.test(email.value)){
        emailerror.innerText="Emailul este gresit";
        return false;
    }
    else{
        emailerror.innerText="";
        return true;
    }
}

function validare_telefon(){
    if(!telefonregex.test(telefon.value)){
        telefonerror.innerText="Telefonul este gresit";
        return false;
    }
    else{
        telefonerror.innerText="";
        return true;
    }
}

function update() {
    contactnou.innerHTML = "";
    let filteredData = data.filter(contact => {
        const searchText = cautacont.value.toLowerCase();
        return contact.nume.toLowerCase().includes(searchText) || 
               contact.email.toLowerCase().includes(searchText) || 
               contact.telefon.includes(searchText);
    });

        data.forEach((contact, index) => afiseaza_contact(contact, index));
}

let x=0;
function introducere_contact(){
    if(!validare_nume() || !validare_email() || !validare_telefon()){
        return;
    }
    
    let temp=new Contact(nume.value, email.value, telefon.value);
    data.push(temp);
    localStorage.setItem("content", JSON.stringify(data));
    contactnou.innerHTML+=`<div id="d${x}"><p>Nume: ${temp.nume}</p><p>Email: ${temp.email}</p><p>Telefon: ${temp.telefon}</p><button onclick=stergere_contact(${x})>Sterge</button></div>`;
    x++;
    nume.value = "";
    email.value = "";
    telefon.value = "";
    update();
}


function stergere_contact(index) {
    data.splice(index, 1);
    localStorage.setItem("content", JSON.stringify(data));
    update();
}

function afiseaza_contact(contact, index) {
    contactnou.innerHTML += `<div id="d${index}">
        <p>Nume: ${contact.nume}</p>
        <p>Email: ${contact.email}</p>
        <p>Telefon: ${contact.telefon}</p>
        <button onclick="stergere_contact(${index})">Sterge</button>
    </div>`;
}

window.onload = function () {
    update();
};

addcontact.addEventListener("click", introducere_contact);
cautacont.addEventListener("input", update);

